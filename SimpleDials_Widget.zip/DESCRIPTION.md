Simple widget to display some value in a dial form.

Used http://bernii.github.io/gauge.js/ code. All rights go the respective author.
